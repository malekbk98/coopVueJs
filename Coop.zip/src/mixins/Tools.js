export const Tools = {
    methods: {
        avatar(member) {
            return `https://eu.ui-avatars.com/api/?name=${member.fullname}&rounded=true&bold=true&format=svg&background=fff&color=dc3545`;
        }
    }
}